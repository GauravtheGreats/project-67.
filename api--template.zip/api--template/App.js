import React from "react";
import { Text, View, StyleSheet, Image } from 'react-native';
export default class FetchRandomUser extends React.Component {
  state = {
    loading: true,
    person: null
  };

getInfo = async () => {
    const url = "https://api.randomuser.me/";
//write a code to fetch data
    const data = await response.json();
    this.setState({ person: data.results[0], loading: false });
  }

  componentDidMount = () => {
    this.getInfo();
  };
  render() {
    if (this.state.loading) {
      return <div>loading...</div>;
    }

    if (!this.state.person) {
      return <div>didn't get a person</div>;
    }

    return (
      <View>
       <Image
//write a code to add image 
            />
      <Text style={{fontSize:40,backgroundColor:'blue',margin:15}}>
        <div>{this.state.person.name.first}</div>
        <div>{this.state.person.name.last}</div>
        </Text>
      </View>
    );
  }
}